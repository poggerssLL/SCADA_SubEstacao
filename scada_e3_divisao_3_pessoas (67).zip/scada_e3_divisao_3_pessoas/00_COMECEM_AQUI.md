﻿# SCADA — divisão para três pessoas

Cada pessoa segue seu ROTEIRO_DA_PESSOA.md. Os passos já incluem cliques, propriedades, valores e os scripts a usar.

| Pessoa | Faz |
|---|---|
| 1 | TelaInicial, TelaMenu, TelaUsuarios, Viewer1, Quadro1, login e merge final |
| 2 | TelaEventos, TelaHistorico, TelaAlarmes, BD_SCADA, DadosEventos, HistEventos, HistContatos, ServidorAlarmes e ConfigAlarmes |
| 3 | Driver1, biblioteca_subestacao.lib, DadosEquipamentos, TelaOperacao, TelaCondicoes e os três botões de comando |

## Começar

1. Salvem a versão atual do projeto e fechem o Studio.
2. Cada pessoa copia a mesma pasta completa para seu computador.
3. Cada um edita apenas os objetos da sua função. Mesmo que apareçam na sua cópia, os objetos das outras funções ficam como estão.
4. Mantenham os nomes dos objetos indicados nos roteiros. Eles conectam os três trabalhos.
5. Importem as imagens como Recursos incorporados, seguindo o procedimento dentro de cada guia. Não deixem referências às pastas pessoais.
6. Se faltar um objeto que outro colega está criando, continuem o restante e completem o vínculo depois do merge. Não criem tags fictícias para substituí-lo.

É necessário um E3 por pessoa para editar simultaneamente. Com um único computador, alternem o uso do Studio.

## Juntar no final

1. Cada pessoa salva, fecha o Studio e envia sua pasta completa à pessoa 1.
2. A pessoa 1 guarda as pastas como ENTREGA_P1, ENTREGA_P2 e ENTREGA_P3.
3. Segue 01_INTEGRACAO_FINAL.md: usa a cópia da pessoa 3 como base e traz os objetos das pessoas 1 e 2 pelo Studio.
4. Depois, seguem 02_IMPORTAR_ASSETS_SEM_CAMINHO.md para conferir os recursos e testar em outra pasta/computador.

Não sobreponham os três .prj completos. Cada um ainda contém versões antigas dos objetos que os colegas alteraram. Usuários e permissões são configurados no .dom final pela pessoa 1.

O programa do CLP permanece como está. Só existem os comandos Ligar, Desligar e Falha B1. D2/D3 dependem das chaves físicas da bancada.

# Pessoa 3 — aquisição, biblioteca, sinótico e condições de operação

Sua função é garantir que o que aparece no sinótico e na comparação corresponde aos contatos reais disponíveis. Você não programa manobras; o controle já funciona.

## Seus objetos — responsabilidade exclusiva

- Driver1 e suas 19 tags de comunicação.
- biblioteca_subestacao.lib, com TagDisjuntor/TagSeccionadora e Disjuntores/Seccionadora.
- DadosEquipamentos e suas instâncias, se necessárias pelo contrato da biblioteca.
- TelaOperacao e TelaCondicoes.
- Três botões operacionais preparados e desabilitados até a bancada.

Não edite as telas da pessoa 1 ou 2. Sua cópia inteira será a BASE da integração final, porque preserva a aquisição e a biblioteca juntas. Isso não autoriza alterar os objetos dos colegas que ainda existem nessa cópia antiga.

## Comece aqui

1. Cada pessoa abre uma cópia da mesma versão atual do projeto. Antes de copiar, Salvar Tudo e fechar o Studio.
2. Edite somente os objetos da sua função, na sua cópia local.
3. Mantenha os nomes indicados nas tabelas: os scripts dependem deles.
4. Nas etapas com imagens, siga primeiro os passos de Inserir Recurso e só depois vincule a figura. A importação está na própria etapa de uso.
5. Quando terminar, Salvar Tudo, fechar o Studio e enviar a pasta completa à pessoa 1 para juntar as partes.

O CLP permanece como está. D2/D3 são acionados pelas chaves físicas. Se faltar um objeto que outro colega está criando, continue a montagem e conecte essa referência depois do merge; não crie tags fictícias.

## C1. Editar propriedades

1. Selecione o objeto na árvore **Organizer**, à esquerda.
2. Confira o nome no título do painel **Propriedades**, abaixo do Organizer.
3. Se esse painel estiver escondido, use **Lista de Propriedades** na barra/menu Visualizar.
4. No campo **Procurar**, escreva o nome da propriedade, por exemplo Width.
5. Clique na célula da coluna **Valor**, na mesma linha.
6. Digite o valor e pressione Enter.
7. Confira se o valor permaneceu.
8. Limpe Procurar antes de procurar outra propriedade.

**Name** é o nome técnico do objeto. **Value**, em Texto/Display nativo, é o conteúdo mostrado. **Caption**, em CommandButton, é o texto do botão. Não são a mesma coisa.

## C2. Colar um código em um evento

1. Abra a tela com duplo clique no Organizer.
2. Selecione o botão na árvore, não apenas um texto desenhado por cima dele.
3. Clique na aba inferior **Scripts**.
4. Na lista superior esquerda, confirme o nome do botão.
5. Na lista superior direita, escolha **Click**.
6. Leia as ações que já existem. Se houver Pick de abrir tela ou Script, não acrescente outra abertura igual.
7. Se estiver vazio, clique em **Script**, na barra desse editor.
8. O Studio cria a linha Sub e a linha End Sub.
9. Abra o .txt indicado em scripts_para_colar, no Bloco de Notas.
10. Copie o conteúdo.
11. No E3, clique na linha vazia entre Sub e End Sub e cole.
12. Não cole uma segunda assinatura Sub/End Sub. Os arquivos normais do pacote já são corpos de evento.
13. Clique em **Compila o script selecionado**, ou pressione F7 com o editor focado.
14. Corrija qualquer erro antes de executar.
15. Clique em Salvar Tudo.

Se estiver substituindo um código antigo, substitua o corpo desse Script; não crie um segundo Script fazendo a mesma coisa.

## C3. Associar uma leitura pelo AppBrowser

1. Selecione o objeto que deve mostrar a informação.
2. Ache sua propriedade de destino, por exemplo Value.
3. Abra a edição de **Associações**, pelo indicador ao lado da propriedade ou pela janela de propriedades do objeto.
4. Escolha **Simples** para ler a informação.
5. Abra o **AppBrowser** no campo de origem.
6. Navegue até a tag e a propriedade exata: por exemplo Driver1 → Aux_D1 → Value.
7. Confirme a seleção e feche com OK.
8. Confira que a associação ficou em Value, e não em Name ou X.
9. Não escolha Bidirecional para os contatos de posição.

Os nomes dos comandos de inserção/diálogos podem variar na sua instalação. Use o nome do objeto e da propriedade para localizar o equivalente; não escolha um tipo diferente só porque está próximo no menu.

## P3.1 Preparar somente suas telas

1. Abra TelaOperacao existente e preserve o desenho.
2. Ajuste somente essa tela para Width=44026,67 e Height=26035.
3. Crie TelaCondicoes no .prj existente se não existir: 1664×984 pixels no assistente, ou as mesmas medidas HIMETRIC.
4. Aplique fundo sólido RGB 243,245,247 e texto RGB 23,43,58 às suas duas telas.
5. Use Segoe UI e preserve o sinótico nativo. Não coloque sinotico_base.png como outra camada de fios.
6. Não redimensione as definições inteiras dos XControls para encaixar o desenho.
7. Não ajuste TelaInicial/TelaMenu: são responsabilidade da pessoa 1.
8. Salve Tudo.


## P3.2 Mapear os contatos

Esta etapa muda o que o SCADA lê, não a lógica do CLP. Preserve canal/dispositivo e a configuração de comunicação existente. Os valores N2/N3 abaixo seguem o mapa SNP dos prints e precisam corresponder à DLL usada na bancada.

1. Expanda **Objetos de Servidor → Drivers e OPC**.
2. Abra Driver1.
3. Confira a configuração atual antes de alterar.
4. Localize Sec_S1.
5. Na propriedade Name dessa tag, troque para **Aux_S1**.
6. Na tabela, configure **N2=0** e **N3=1**. Os cabeçalhos podem aparecer como P2/N2/B2 e P3/N3.
7. Preserve N1 e N4. No print, ambos eram 0 nas tags de aquisição.
8. Habilite Leitura e desabilite Escrita. Na lista de propriedades, esses campos podem aparecer como AllowRead/AllowWrite.
9. Mantenha o período de leitura de 1000 ms, conforme a configuração atual.
10. Repita uma linha de cada vez:

| Antiga | Novo Name | N2 | N3 | Endereço | Leitura | Escrita |
|---|---|---:|---:|---|---|---|
| Sec_S1 | Aux_S1 | 0 | 1 | %I00001 | Sim | Não |
| Sec_S2 | Aux_S2 | 0 | 2 | %I00002 | Sim | Não |
| Sec_S3 | Aux_S3 | 0 | 3 | %I00003 | Sim | Não |
| Sec_S4 | Aux_S4 | 0 | 4 | %I00004 | Sim | Não |
| Sec_S5 | Aux_S5 | 0 | 5 | %I00005 | Sim | Não |
| Sec_S6 | Aux_S6 | 0 | 6 | %I00006 | Sim | Não |
| Sec_S7 | Aux_S7 | 0 | 7 | %I00007 | Sim | Não |
| Sec_S8 | Aux_S8 | 0 | 8 | %I00008 | Sim | Não |
| Sec_S9 | Aux_S9 | 0 | 9 | %I00009 | Sim | Não |
| Sec_S10 | Aux_S10 | 0 | 10 | %I00010 | Sim | Não |

11. Confira **Aux_D1, Aux_D2, Aux_D3**: N2=0; N3=11,12,13 respectivamente; Leitura=Sim; Escrita=Não.
12. Preserve **Disj_D1, Disj_D2, Disj_D3** como leituras das ordens de saída: N2=2; N3=6,5,4 respectivamente; Escrita=Não.
13. Confira os três comandos abaixo sem escrever valores:

| Nome visto no print | Memória | N2/N3 de referência |
|---|---|---|
| Botao_Liga_NA | %M00600 | 6 / 600 |
| Botap_Desliga_NF | %M00602 | 6 / 602 |
| Botao_Falha_NA | %M00601 | 6 / 601 |

14. Confirme a grafia real do segundo nome. Não renomeie por suposição.
15. Não substitua os demais parâmetros dessas memórias. A tabela indica a referência de endereço, não uma nova configuração completa.
16. Conte as tags: 10 Aux_S + 3 Aux_D + 3 Disj_D + 3 comandos = **19 tags de comunicação**.
17. Não mantenha as dez Sec_S antigas e acrescente dez Aux_S novas nesta receita Demo.
18. Se aparecer associação quebrada com Sec_S, abra-a e selecione o Aux_S correspondente no AppBrowser. O novo significado é contato de posição.
19. Salve Tudo e confira se o Demo aceita o salvamento.

**Resultado esperado:** 13 entradas somente leitura; 3 saídas somente leitura; só três memórias de comando; 19 tags.


## P3.3 Conferir e associar a biblioteca

### Se o componente usa imagem, incorpore-a antes de alterar sua indicação

Os componentes vetoriais existentes não precisam ser substituídos por PNG. Se você encontrar uma Figura com Filename externo, ou decidir usar uma imagem em um XControl:

1. No Organizer, abra Visualização → Recursos → **Inserir Recurso Em → biblioteca_subestacao.lib**.
2. Escolha o PNG/BMP necessário, confirme e nomeie com prefixo **P3_**, por exemplo P3_IndicadorAberto.
3. Salve Tudo. Abra o XControl e selecione a Figura interna.
4. Localize Filename e arraste o Recurso do Organizer para esse campo; não volte a escolher o arquivo pelo Windows.
5. Se a imagem for de uma tela, e não interna da classe, incorpore no .prj dessa tela em vez da .lib e faça o mesmo vínculo.
6. Confira a Figura, registre as bibliotecas e Salve Tudo. Preserve a topologia nativa; não importe sinotico_base como substituto do desenho.

### 15.1 Olhar o que o grupo já criou

1. Expanda **Bibliotecas de Objetos → XObjects**.
2. Abra TagDisjuntor.
3. Clique na aba **Propriedades** e confira os campos públicos e seus tipos.
4. Procure identificação, retorno de posição e qualidade ou referência de tag.
5. Repita em TagSeccionadora.
6. Expanda XControls, abra Disjuntores e vá à aba Propriedades.
7. Confira **FONTE**, tipo **TagDisjuntor**. Esse foi o vínculo confirmado na inspeção.
8. Abra Seccionadora e confira seu campo de referência. Não suponha a grafia.
9. Não crie Nome/Estado por adivinhação se a mesma função já existir com outro nome.
10. Não altere o tamanho da página inteira da definição Disjuntores para encaixar o símbolo: isso pode afetar todas as instâncias.

### 15.2 Entender a referência FONTE

Se o XControl recebe um XObject, o caminho é:

```text
Driver1.Aux_D1.Value e Quality
        ↓ leituras
instância de TagDisjuntor para D1 em Objetos de Dados
        ↓ referência de objeto
FONTE do Disjuntores correspondente a D1 em TelaOperacao
```

1. Expanda **Objetos de Servidor → Objetos de Dados**.
2. Veja se já existem instâncias dos XObjects. Definição em Bibliotecas de Objetos não é uma instância de dados.
3. Se existirem, reaproveite-as e confira suas associações.
4. Se faltarem, crie um Servidor/Pasta de Dados chamado **DadosEquipamentos**, no .prj.
5. Dentro dele, pelo comando Inserir, selecione a classe TagDisjuntor da biblioteca.
6. Crie uma instância para D1, outra para D2 e outra para D3.
7. Crie analogamente as dez instâncias de TagSeccionadora, se esse for o contrato encontrado.
8. No campo de retorno de D1, faça associação simples a **Driver1.Aux_D1.Value**.
9. No campo de qualidade de D1, associe **Driver1.Aux_D1.Quality**.
10. Se o campo da classe for referência de objeto/Tag, selecione a tag inteira, em vez de Value. O tipo declarado decide isso.
11. Na instância gráfica de D1, associe FONTE à instância de TagDisjuntor de D1.
12. **Não associe FONTE ao número 0/1 de Aux_D1.Value:** ela espera um objeto TagDisjuntor.
13. Termine um equipamento e confira antes de repetir nos outros 12.
14. Se a classe não tiver campo de posição/qualidade, deixe essa associação pendente e use a conferência de Displays da P3.5. Não invente propriedades existentes nem deixe a indicação aprovar um dado inválido.


## P3.4 Identificar o sinótico

1. Abra TelaOperacao.
2. Preserve todos os conectores e as instâncias posicionadas.
3. Identifique cada equipamento pela ligação ao barramento/ramal, conferindo o unifilar do PDF.
4. Use esta tabela de função como apoio. Os números automáticos do Organizer não provam a correspondência física:

| Função no unifilar | Equipamento |
|---|---|
| Fonte B1 do ramo direto da Linha 1 | S1 |
| Fonte B2 do ramo direto da Linha 1 | S2 |
| Disjuntor direto da Linha 1 | D1 |
| Seccionadora após D1 para Linha 1 | S3 |
| Auxiliar para Linha 1 | S4 |
| Fonte B1 do ramo direto da Linha 2 | S5 |
| Fonte B2 do ramo direto da Linha 2 | S6 |
| Disjuntor direto da Linha 2 | D2 |
| Seccionadora após D2 para Linha 2 | S7 |
| Auxiliar para Linha 2 | S8 |
| Alimentação auxiliar por B1 | S9 |
| Alimentação auxiliar por B2 | S10 |
| Disjuntor horizontal de interligação auxiliar | D3 |

5. Clique em uma instância no desenho e confira qual objeto foi selecionado na árvore.
6. Identifique o equipamento físico correspondente ao objeto selecionado.
7. Atualize o texto Nome pelo campo de identificação exposto na biblioteca, se ele existir.
8. Se o texto ainda for fixo dentro da definição, **não troque Nome por D1 dentro da classe compartilhada**: todos os disjuntores passariam a mostrar D1.
9. Nesse caso, acrescente um campo público String de identificação à classe, associe o Value do texto a esse campo pelo AppBrowser e informe D1/D2/D3 nas instâncias. Preserve as propriedades anteriores.
10. Faça o mesmo para S1–S10, se necessário.
11. Preserve a orientação horizontal de D3.
12. Confira se aberto/fechado lê o contato Aux correspondente e se a qualidade inválida prevalece como desconhecido.
13. Não use uma saída Disj_D como se fosse confirmação de posição.
14. Deixe os fios e barras estáticos em cinza enquanto não houver inferência válida de energização.
15. Acrescente a legenda **Posição pelos contatos auxiliares. Não representa medição de tensão.**
16. Depois de alterar definições, use **Registrar Bibliotecas** e Salvar Tudo.

**Resultado esperado:** Rótulos certos; fontes certas; qualidade considerada; desenho preservado.


## P3.5 Conferir sinais

Você pode colocar esta tabela na lateral do sinótico ou em uma área de TelaCondicoes. Ela é útil se algum vínculo da biblioteca estiver pendente.

1. Crie um Texto: **Contatos: 0=aberto e 1=fechado, somente com qualidade boa**.
2. Insira um objeto **Display** nativo pela barra de desenho.
3. Dê o nome dispS1.
4. Associe Value a Driver1.Aux_S1.Value, usando procedimento C3.
5. Crie um Texto ao lado com Value=S1.
6. Crie outro Display, nome qualS1, Value associado a Driver1.Aux_S1.Quality.
7. Coloque o rótulo Qualidade acima da segunda coluna.
8. Repita uma linha para cada S2–S10 e D1–D3, sempre trocando a origem para o Aux correspondente.
9. Um valor numérico sem qualidade boa não confirma a posição. O comparador da P3.6 já trata essa condição.
10. Para D3, mostre dois campos adicionais e separados: **Ordem D3 → Driver1.Disj_D3.Value** e **Retorno D3 → Driver1.Aux_D3.Value**. Mostre também a qualidade de cada origem.
11. Não force as tags para testar cor. A ausência de comunicação fora da bancada é esperada.


## P3.6 Construir TelaCondicoes

### 19.1 Seleção local e botões

1. Abra TelaCondicoes.
2. Crie um Texto de título: **Condições de operação — esperado × observado**.
3. Clique com o botão direito na própria TelaCondicoes, na árvore, e insira um **Tag Interno**.
4. Nomeie **CasoSelecionado** e deixe Value=0.
5. Confira que o Tag está dentro da TelaCondicoes. Não o crie no Driver1 ou como tag global de processo.
6. Crie cinco CommandButtons:

| Name | Caption | Arquivo para Click |
|---|---|---|
| btnNormal | Comparar: normal | consultar_condicao_1.txt |
| btnB1 | Comparar: falha B1 | consultar_condicao_2.txt |
| btnAuxL2 | Comparar: D2 / auxiliar L2 | consultar_condicao_3.txt |
| btnD3 | Conferência: D3 não abre | consultar_condicao_4.txt |
| btnAtualizar | Atualizar leitura | atualizar_condicao.txt |

7. Organize os quatro casos em duas linhas, com Atualizar logo abaixo ou à direita.
8. **Não coloque Pick de escrever tag nesses botões.** Eles são consultas.

### 19.2 Campos que os scripts vão preencher

1. Crie quatro objetos **Texto nativo do E3**, não Label/TextBox do Forms.
2. Configure os nomes exatos e os Values iniciais:

| Name | Value inicial |
|---|---|
| txtCaso | Nenhuma referência selecionada |
| txtResultado | NÃO AVALIADO |
| txtInstante | Sem leitura |
| txtDetalhes | Selecione uma referência para consultar os contatos. |

3. Faça txtResultado largo para caber duas linhas.
4. Em txtDetalhes, habilite Multiline/WordWrap se disponíveis.
5. Reserve uma área grande, com pelo menos 15 linhas legíveis.
6. Sugestão em HIMETRIC: X=635; Y=6879,17; Width=42597,92; Height=16933,33. Ajuste se reservou uma área para a tabela de Displays.
7. Use fonte Segoe UI 17–18 como referência visual e confira o encaixe no Viewer.
8. Acrescente o aviso fixo: **Consulta por fotografia. Atualize após a manobra. Não mede tensão/corrente e não comanda o circuito.**

### 19.3 Colar e testar

1. Cole cada arquivo da tabela no Click do botão da mesma linha, seguindo procedimento C2.
2. Selecione a própria TelaCondicoes na árvore.
3. Em Scripts, escolha **OnPreShow**.
4. Crie o Script se estiver vazio e cole **condicoes_ao_abrir.txt** dentro da assinatura criada pelo Studio.
5. Compile todos os eventos e Salve Tudo.
6. Abra o Viewer por Quadro1 e clique Condições de operação.
7. A tela deve iniciar em NÃO AVALIADO.
8. Clique Comparar: normal. Sem comunicação válida, o esperado é INCONCLUSIVO.
9. Não mude valores iniciais para conseguir um resultado verde.
10. Clique Atualizar e confira se o horário da fotografia muda.
11. Clique Conferência: D3 não abre. Esse caso deve ser guiado, sem aprovação automática.
12. Saia da tela e volte. O resultado anterior deve ser limpo pelo OnPreShow.
13. Feche o Viewer para continuar.

**Resultado esperado:** Sem erro de objeto; consulta não escreve; sem leitura não aprova; horário atualiza.


## P3.7 Preparar os comandos

1. Abra TelaOperacao e reserve a lateral direita para os comandos, fora dos fios.
2. Crie os três CommandButtons:

| Name | Caption | Memória após conferir contrato |
|---|---|---|
| btnLigar | Ligar sistema | %M00600 |
| btnDesligar | Desligar sistema | %M00602 |
| btnFalhaB1 | Falha de alimentação B1 | %M00601 |

3. Configure **Enabled=False** nos três nesta montagem fora da bancada.
4. Acrescente o Texto: **Comandos aguardando conferência do contrato na bancada.**
5. Não crie a ação de escrita por enquanto. O PDF não define se a memória é pulso ou nível, sua duração nem quem retorna a zero.
6. Na bancada, confira esse contrato no funcionamento existente.
7. Só então escolha a tag da memória pelo AppBrowser e configure o Pick/ação de escrita compatível com esse contrato.
8. Não invente um pulso de 100, 500 ou 1000 ms.
9. Não crie comandos individuais S/D nem botão Falhar D2, Travar D3 ou Reset físico.
10. As falhas D2/D3 são provocadas pelas chaves da bancada.
11. O registro de evento que vem depois não substitui a escrita real nem comprova conclusão da manobra.


## P3.8 Preparar registro da consulta

1. Em TelaCondicoes, crie btnRegistrarConsulta com Caption=Registrar consulta.
2. Cole registrar_verificacao_demo.txt no Click e compile.
3. Durante o trabalho isolado, mantenha esse botão Enabled=False: DadosEventos/HistEventos são responsabilidade da pessoa 2 e podem ainda não existir.
4. Não crie cópias temporárias desses objetos.
5. Depois da integração e de confirmar HistEventos, habilite esse botão e confira o registro na TelaEventos.
6. Os arquivos de registrar solicitação dos três comandos são apenas metadados. Não os confunda com escrita operacional nem registre como manobra concluída.
7. Os três comandos continuam desabilitados até a verificação física do contrato, mesmo com banco funcionando.


## P3.9 Passar a base à pessoa 1

1. Salve Tudo e confira que o Demo salva as 19 tags.
2. Feche o Studio e envie a pasta completa como ENTREGA_P3: .dom, .prj, .lib, DLLs já usadas e recursos.
3. A pessoa 1 fará uma cópia dessa pasta para juntar as partes. Driver1, a biblioteca e suas duas telas serão preservados.
4. Depois do merge, confira contatos, qualidade e comparação. A validação física continua sendo feita na bancada.


## Referência de condições e interpretação

### 11.2 Matriz de referência

O caminho normal da Linha 2 segue expressamente o texto das imagens enviadas: **S6 e S7, depois D2**, e não S5. Isso é uma referência de comparação; o E3 não envia essa sequência ao CLP.

| Caso | Contatos fechados esperados | Contatos abertos de referência | Alcance |
|---|---|---|---|
| Normal | S1, S3, D1; S6, S7, D2 | S2, S4, S5, S8 | L1 direta de B1 e L2 direta de B2, pontos 1-2-4 e 8-7-9 |
| Falha B1 | S2, S3, D1; S6, S7, D2 | S1, S4, S5, S8 | L1 e L2 diretas de B2, pontos 3-2-4 e 8-7-9 |
| D2 indisponível / auxiliar L2 | S9, D3, S8 | D2, S7, S5, S6, S10 | Caminho 11-12-14-10-9, com ramo direto e fonte alternativa auxiliar isolados na configuração de referência |
| D3 não abre | Sem máscara final única | Sem máscara final única | Conferência guiada de ordem/retorno e acompanhamento da recuperação existente |

**Origem dos critérios:** os contatos fechados dos três primeiros casos decorrem dos caminhos e sequências apresentados pelo PDF. Os contatos abertos são condições de referência para isolamento desses caminhos, inferidas do unifilar e da descrição de abertura das seccionadoras anteriores. Não são novas ordens nem nova lógica do controlador. O monitor declara explicitamente esse escopo. Se o controlador existente mantiver uma condição diferente que seja intencional e válida, confirme essa referência antes de classificar o resultado como defeito do processo; não altere a manobra para satisfazer a tela.

Os contatos fora dessas listas são mostrados como **SEM RESTRIÇÃO NESTE CASO**, não aprovados automaticamente. No caso do auxiliar L2, a condição da Linha 1 não foi fixada por esse trecho do PDF e não deve ser inventada pela tela.

### 11.3 Interpretação dos resultados

- **NÃO AVALIADO:** nenhuma referência foi selecionada nesta abertura.
- **INCONCLUSIVO:** falta tag, valor utilizável ou boa qualidade em algum contato exigido. Nunca mostrar verde nesse caso.
- **DIVERGENTE DA REFERÊNCIA:** os dados requeridos são válidos, mas algum contato não corresponde. Pode ser uma transição ainda em curso, outra configuração intencional ou um problema. Não rotular automaticamente como falha mecânica.
- **CONFORME NOS ITENS AVALIADOS:** todos os contatos exigidos correspondem ao quadro de referência. Não comprova tensão, corrente, ausência de defeito físico ou conformidade de estados não avaliados.
- **D3: CONFERÊNCIA GUIADA:** a documentação não fornece um único estado final válido para toda a recuperação de D3 travado. A tela não aprova automaticamente esse caso.

O resultado é uma fotografia com horário. Clique Atualizar depois de novas alterações. O polling não é atômico nem comprova a ordem temporal de cada fechamento. Durante a manobra, espere as confirmações do processo para comparar a configuração final; não introduza temporizadores de controle no E3 para fazê-la ocorrer.

### 11.4 D3 e chaves físicas

1. Exiba em dois campos separados a saída `Disj_D3` e o contato `Aux_D3`, com suas qualidades.
2. Se a ordem estiver em abrir e o contato ainda fechado, descreva **ordem/retorno divergentes no instante consultado**.
3. Isso não identifica sozinho a posição da chave, causa mecânica ou fim da temporização existente. Não declare a chave em Defeito se não houver sinal que a represente.
4. O operador pode registrar uma anotação `Chave D3 em Defeito - informação do operador`, distinguindo declaração manual de sinal lido.
5. Acompanhe a recuperação executada pelo controle já funcionando. Não abra/feche seccionadoras pelo SCADA para completar a recuperação.


## Testar as imagens depois de montar

1. Salve Tudo e feche o Viewer e o Studio.
2. Copie a aplicação entregue para uma segunda pasta com outro nome, por exemplo TESTE_PORTABILIDADE_SCADA.
3. Nessa cópia, mantenha .dom, todos os .prj, a .lib, DLLs e a pasta dados necessária.
4. Feche todas as instâncias antigas antes do teste, para evitar imagem carregada em cache.
5. Renomeie temporariamente APENAS a pasta externa de imagens usada como fonte no seu computador, por exemplo SCADA_UI para SCADA_UI_FONTE_TEMP. Se o arquivo original foi lido de assets do pacote, essa pasta de origem também precisa ficar indisponível no teste. Não renomeie dados, drivers, projeto ou biblioteca.
6. Abra o domínio da segunda pasta. Confirme o novo caminho na barra de título.
7. Abra o Viewer e visite todas as telas; confira fundos, ícones e símbolos que usam imagens.
8. Se faltou imagem, volte à etapa em que inseriu essa figura, incorpore o recurso no arquivo correto e refaça o vínculo pelo Organizer. Salve e repita o teste.
9. Ao terminar, feche o Studio e restaure os nomes das pastas de imagens de origem. Não apague nenhuma pasta.
10. O melhor teste final é abrir a entrega em outro computador onde os caminhos dos autores nunca existiram. Esse teste também revela DLL/provider ausente, que é problema diferente de asset.
11. Considere o teste concluído quando todas as imagens aparecerem após reabrir sem as pastas-fonte.

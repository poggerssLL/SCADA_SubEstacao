# Pessoa 2 — banco, eventos, histórico e alarmes

Sua função é cuidar da persistência e das três telas de consulta. Não altere a navegação geral, o sinótico, a biblioteca ou a aquisição.

## Seus objetos — responsabilidade exclusiva

- TelaEventos, TelaHistorico, TelaAlarmes e seus objetos internos.
- BD_SCADA, DadosEventos, HistEventos, HistContatos.
- ServidorAlarmes e ConfigAlarmes, incluindo a área Supervisao.
- Banco local de teste em dados, com registros identificados como testes de interface.

Não edite TelaInicial/TelaMenu/TelaUsuarios/Viewer1/Quadro1 (pessoa 1), nem Driver1/TelaOperacao/TelaCondicoes/biblioteca (pessoa 3).

## Comece aqui

1. Cada pessoa abre uma cópia da mesma versão atual do projeto. Antes de copiar, Salvar Tudo e fechar o Studio.
2. Edite somente os objetos da sua função, na sua cópia local.
3. Mantenha os nomes indicados nas tabelas: os scripts dependem deles.
4. Nas etapas com imagens, siga primeiro os passos de Inserir Recurso e só depois vincule a figura. A importação está na própria etapa de uso.
5. Quando terminar, Salvar Tudo, fechar o Studio e enviar a pasta completa à pessoa 1 para juntar as partes.

O CLP permanece como está. D2/D3 são acionados pelas chaves físicas. Se faltar um objeto que outro colega está criando, continue a montagem e conecte essa referência depois do merge; não crie tags fictícias.

## C1. Editar propriedades

1. Selecione o objeto na árvore **Organizer**, à esquerda.
2. Confira o nome no título do painel **Propriedades**, abaixo do Organizer.
3. Se esse painel estiver escondido, use **Lista de Propriedades** na barra/menu Visualizar.
4. No campo **Procurar**, escreva o nome da propriedade, por exemplo Width.
5. Clique na célula da coluna **Valor**, na mesma linha.
6. Digite o valor e pressione Enter.
7. Confira se o valor permaneceu.
8. Limpe Procurar antes de procurar outra propriedade.

**Name** é o nome técnico do objeto. **Value**, em Texto/Display nativo, é o conteúdo mostrado. **Caption**, em CommandButton, é o texto do botão. Não são a mesma coisa.

## C2. Colar um código em um evento

1. Abra a tela com duplo clique no Organizer.
2. Selecione o botão na árvore, não apenas um texto desenhado por cima dele.
3. Clique na aba inferior **Scripts**.
4. Na lista superior esquerda, confirme o nome do botão.
5. Na lista superior direita, escolha **Click**.
6. Leia as ações que já existem. Se houver Pick de abrir tela ou Script, não acrescente outra abertura igual.
7. Se estiver vazio, clique em **Script**, na barra desse editor.
8. O Studio cria a linha Sub e a linha End Sub.
9. Abra o .txt indicado em scripts_para_colar, no Bloco de Notas.
10. Copie o conteúdo.
11. No E3, clique na linha vazia entre Sub e End Sub e cole.
12. Não cole uma segunda assinatura Sub/End Sub. Os arquivos normais do pacote já são corpos de evento.
13. Clique em **Compila o script selecionado**, ou pressione F7 com o editor focado.
14. Corrija qualquer erro antes de executar.
15. Clique em Salvar Tudo.

Se estiver substituindo um código antigo, substitua o corpo desse Script; não crie um segundo Script fazendo a mesma coisa.

## C3. Associar uma leitura pelo AppBrowser

1. Selecione o objeto que deve mostrar a informação.
2. Ache sua propriedade de destino, por exemplo Value.
3. Abra a edição de **Associações**, pelo indicador ao lado da propriedade ou pela janela de propriedades do objeto.
4. Escolha **Simples** para ler a informação.
5. Abra o **AppBrowser** no campo de origem.
6. Navegue até a tag e a propriedade exata: por exemplo Driver1 → Aux_D1 → Value.
7. Confirme a seleção e feche com OK.
8. Confira que a associação ficou em Value, e não em Name ou X.
9. Não escolha Bidirecional para os contatos de posição.

Os nomes dos comandos de inserção/diálogos podem variar na sua instalação. Use o nome do objeto e da propriedade para localizar o equivalente; não escolha um tipo diferente só porque está próximo no menu.

## P2.1 Criar apenas suas telas

1. No Organizer, expanda Visualização → Telas.
2. Insira uma Tela no .prj existente e nomeie TelaEventos, se estiver ausente.
3. No assistente use 1664×984 pixels, ou ajuste Width=44026,67 e Height=26035 na lista de propriedades.
4. Repita para TelaHistorico e TelaAlarmes.
5. Em cada uma, aplique preenchimento sólido RGB 243,245,247, texto RGB 23,43,58 e Segoe UI.
6. Não crie as outras telas. Não duplique Viewer1 para testar; use o Viewer existente na sua cópia, sem alterar sua configuração persistida para a entrega.
7. Para conferir uma tela isolada, use o recurso de visualizar/executar a tela atual disponível no Studio; isso não é teste da navegação geral.
8. Salve Tudo.

### Ícones opcionais das suas telas — importar antes de usar

As três telas funcionam com fundo sólido e objetos nativos; não precisam de imagem. Se adicionar um ícone:

1. Em Visualização → Recursos, clique com o botão direito → **Inserir Recurso Em → seu .prj de registros**.
2. Escolha o PNG em assets/icones, confirme e nomeie, por exemplo **P2_IconeEventos**.
3. Salve Tudo. Só depois insira uma Figura nativa na tela.
4. Selecione a Figura, localize Filename e arraste o recurso do Organizer para essa propriedade. Não selecione o arquivo externo novamente.
5. Confira a imagem e Salve Tudo. Repita apenas para os ícones realmente usados.


## P2.2 Criar e testar o banco

1. Confira a pasta dados junto ao .prj.
2. No Organizer, clique com o botão direito em **Objetos de Servidor → Banco de Dados**.
3. Insira um objeto Banco de Dados no .prj existente.
4. Dê o nome **BD_SCADA**.
5. Abra a configuração do banco.
6. Escolha Access / stAccess, se disponível.
7. Configure o arquivo **dados\scada.mdb**, relativo à pasta do projeto. Se o campo exigir caminho absoluto, escolha explicitamente essa pasta pelo seletor.
8. Use o comando de criar/conectar/testar disponível no editor do banco.
9. Se houver erro de provider, arquitetura ou permissão, resolva a conexão antes de testar a gravação. Não instale componentes aleatórios.
10. Você pode continuar desenhando as telas, mas gravação só estará pronta depois que a conexão funcionar.


## P2.3 Criar os registros de evento

Não use Domínio → Opções como dependência desta receita: esse recurso é limitado no Demo. O caminho aqui é Histórico com gravação manual.

### 22.1 DadosEventos

1. Em **Objetos de Dados**, insira um Servidor de Dados chamado **DadosEventos**, no .prj.
2. Dentro dele, insira quatro Tags Internos:

| Name | Value inicial | Tipo, se o editor oferecer |
|---|---|---|
| Mensagem | Texto vazio | String/texto |
| Usuario | Texto vazio | String/texto |
| Categoria | Texto vazio | String/texto |
| Comentario | Texto vazio | String/texto |

3. Se o Tag for Variant, use valor inicial textual compatível.
4. Não associe esses Tags ao Driver1. Eles são campos de um registro, não estados simulados do processo.

### 22.2 HistEventos

1. Em Objetos de Servidor, insira um **Histórico** no .prj.
2. Nomeie **HistEventos**.
3. Configure **DBServer=BD_SCADA**.
4. Configure **TableName=EventosSCADA**.
5. Configure **ScanTime=0**, para gravação manual por WriteRecord.
6. Abra **Fields / Campos** no editor do Histórico.
7. Adicione os quatro campos abaixo, tipo texto, tamanho 255:

| Campo | Fonte de leitura |
|---|---|
| Mensagem | DadosEventos.Mensagem.Value |
| Usuario | DadosEventos.Usuario.Value |
| Categoria | DadosEventos.Categoria.Value |
| Comentario | DadosEventos.Comentario.Value |

8. Preserve o campo nativo **E3TimeStamp**. Não crie outro com esse nome.
9. Use **Gerar Tabela** para criar a estrutura no banco.
10. Se avisar que já existe tabela e vai reinicializar, cancele e confira. Não apague registros para repetir a montagem.
11. Salve Tudo.


## P2.4 Montar o Browser de eventos

### 23.1 Tabela visual

1. Abra TelaEventos.
2. Crie um Texto de título: **Tabela de eventos**.
3. Na barra de objetos, escolha **E3Browser — Tabela de Dados**.
4. Desenhe-o na região central, com espaço para título e botões.
5. Configure **Name=brwEventos**.
6. Abra suas propriedades/configuração e localize **Consulta / Query**.
7. Abra o editor dessa Consulta, selecione **BD_SCADA** e a tabela **EventosSCADA**.
8. Selecione E3TimeStamp, Mensagem, Usuario, Categoria e Comentario.
9. Configure ordenação por E3TimeStamp decrescente.
10. Teste a Consulta. Sem eventos, zero linhas é aceitável; erro de tabela inexistente não é.
11. No Browser, use o recurso de recuperar/configurar colunas da Consulta.
12. Deixe Mensagem e Comentario com mais largura.
13. Crie btnAtualizarEventos, Caption=Atualizar.
14. Cole **atualizar_eventos.txt** no Click.


## P2.5 Comprovar uma anotação sem alterar telas alheias

1. Dentro de TelaEventos, crie btnAnotar com Caption=Anotar observação.
2. Cole registrar_anotacao_demo.txt no Click, compile e Salve Tudo.
3. Abra sua tela isolada no Viewer e clique Anotar observação.
4. Digite Teste de registro da interface — sem comando de processo.
5. Clique Atualizar e confira a linha, horário e categoria DECLARACAO_MANUAL.
6. Feche e reabra a consulta/Viewer e confira que a linha permanece.
7. Não altere o login da TelaInicial: é da pessoa 1.
8. Não crie btnRegistrarConsulta na TelaCondicoes: é da pessoa 3.
9. Informe aos colegas que HistEventos está pronto e entregue os caminhos exatos. Os scripts correspondentes já estão nos pacotes deles.
10. Não execute os scripts de registrar solicitação para fingir comando real. WriteRecord não escreve no CLP.


## P2.6 Histórico e consulta de contatos

### 24.1 Histórico de aquisição

1. Insira outro Histórico no .prj, nome **HistContatos**.
2. Configure DBServer=BD_SCADA.
3. Configure TableName=ContatosSCADA.
4. Configure ScanTime=1000 ms. Isso é amostragem do SCADA, não temporizador da manobra.
5. Em Fields, adicione 13 campos:

| Campo | Origem |
|---|---|
| S1 | Driver1.Aux_S1.Value |
| S2 | Driver1.Aux_S2.Value |
| S3 | Driver1.Aux_S3.Value |
| S4 | Driver1.Aux_S4.Value |
| S5 | Driver1.Aux_S5.Value |
| S6 | Driver1.Aux_S6.Value |
| S7 | Driver1.Aux_S7.Value |
| S8 | Driver1.Aux_S8.Value |
| S9 | Driver1.Aux_S9.Value |
| S10 | Driver1.Aux_S10.Value |
| D1 | Driver1.Aux_D1.Value |
| D2 | Driver1.Aux_D2.Value |
| D3 | Driver1.Aux_D3.Value |

6. Use tipo Bit/Boolean ou inteiro compatível com 0/1 no editor.
7. Preserve E3TimeStamp.
8. Em cada campo, habilite **qualidade real do Tag**, se oferecida pelo editor. Não escolha a modalidade sem qualidade.
9. Se precisar de colunas explícitas de qualidade, acrescente QS1–QS10 e QD1–QD3, tipo inteiro, associados à propriedade Quality de cada Aux correspondente.
10. Prefira a qualidade real vinculada ao próprio campo. As colunas explícitas são uma alternativa de visualização, cuja leitura pode não ser atômica.
11. Opcionalmente, adicione OrdemD1–OrdemD3, associados a Disj_D1–Disj_D3. Não substitua os contatos pelas ordens.
12. Gere a estrutura da tabela e Salve Tudo. Não reinicialize uma tabela já preenchida.

### 24.2 Consulta visual

1. Abra TelaHistorico.
2. Crie o título **Histórico de contatos**.
3. Insira E3Browser com **Name=brwHistorico**.
4. Abra sua Consulta, selecione BD_SCADA e ContatosSCADA.
5. Selecione E3TimeStamp, S1–S10, D1–D3 e as qualidades armazenadas disponíveis.
6. Ordene por E3TimeStamp decrescente.
7. Teste a Consulta e recupere as colunas no Browser.
8. Crie btnAtualizarHistorico, Caption=Atualizar.
9. Cole **atualizar_historico.txt** no Click.
10. Compile e Salve Tudo.
11. Fora da bancada, dados com qualidade inválida não comprovam posições físicas.
12. Na bancada, consulte registros antes e depois de uma manobra existente e confira sua persistência após reabrir.

### 24.3 Gráfico opcional — só depois da tabela

1. Acrescente E3Chart apenas após a consulta tabular funcionar.
2. Configure penas históricas provenientes do banco/Consulta.
3. Comece com D1, D2 e D3 e identifique-os como contatos digitais 0/1.
4. Configure intervalo de tempo e legenda.
5. Compare um trecho do gráfico com as linhas da tabela.
6. Não crie gráficos de tensão/corrente sem medições disponíveis. O registro de 1 s não comprova sequência de eventos com precisão de milissegundos.

### Se Aux_S ainda não existir na sua base

A pessoa 3 faz o remapeamento. Não mude Driver1. Crie os campos e informe os caminhos Driver1.Aux_Sn.Value e Quality se o editor aceitar. Se ele exigir uma tag existente, complete essa associação depois do merge. Não associe à saída Sec_S no lugar do contato. Sem contato válido, o histórico ainda não confirma posição física.


## P2.7 Tela de alarmes

1. Expanda **Objetos de Servidor → Alarmes**.
2. Insira Servidor de Alarmes, nome **ServidorAlarmes**, se não existir.
3. Insira Configuração de Alarmes, nome **ConfigAlarmes**, se não existir.
4. Dentro da configuração, crie a área **Supervisao**.
5. Abra TelaAlarmes e crie o título **Alarmes de supervisão**.
6. Insira **E3Alarm — Sumário de Alarmes**.
7. Associe **AlarmServer** a ServidorAlarmes, pelo AppBrowser.
8. Configure colunas de horário, área, mensagem, severidade e reconhecimento.
9. A lista pode estar vazia nessa fase. Criar o E3Alarm não cria automaticamente fontes de alarme.
10. Configure fontes somente para diagnósticos realmente disponíveis e entendidos, por exemplo qualidade inválida de aquisição ou falha de gravação/conexão do banco.
11. Confira no objeto real o caminho e o critério de cada diagnóstico. Se não houver sinal/critério confirmado, configure essa fonte somente depois de confirmar o sinal e o critério.
12. Não use um bit interno fixo para apresentar falha física de D2/D3.
13. Não associe Reconhecer a memória de comando. Reconhecer não conserta, não muda chave e não dispara manobra.
14. Para persistência dos alarmes, abra a configuração de banco do ServidorAlarmes, selecione BD_SCADA e a tabela AlarmesSCADA e gere a estrutura pela opção nativa disponível.
15. Não reinicialize tabela já usada.
16. A divergência da TelaCondicoes é uma consulta, separada dos alarmes contínuos. Durante transição, não a transforme automaticamente em defeito mecânico.


## P2.8 Passar sua parte à pessoa 1

1. Salve Tudo e feche o Studio.
2. Envie a pasta completa da aplicação como ENTREGA_P2, incluindo dados.
3. Depois do merge, teste BD_SCADA no computador final e complete os vínculos aos contatos Aux da pessoa 3.
4. Confira uma anotação persistente e as consultas de eventos/histórico. Não sobrescreva um banco final já usado com seu banco de teste.

## Preparar o módulo de registros

Se quiser adiantar o merge, siga a seção 3 de 01_INTEGRACAO_FINAL.md para separar Dados_Registros.prj. Mantenha também a cópia completa da sua aplicação. Não leve Driver1 para esse módulo.


## Testar as imagens depois de montar

1. Salve Tudo e feche o Viewer e o Studio.
2. Copie a aplicação entregue para uma segunda pasta com outro nome, por exemplo TESTE_PORTABILIDADE_SCADA.
3. Nessa cópia, mantenha .dom, todos os .prj, a .lib, DLLs e a pasta dados necessária.
4. Feche todas as instâncias antigas antes do teste, para evitar imagem carregada em cache.
5. Renomeie temporariamente APENAS a pasta externa de imagens usada como fonte no seu computador, por exemplo SCADA_UI para SCADA_UI_FONTE_TEMP. Se o arquivo original foi lido de assets do pacote, essa pasta de origem também precisa ficar indisponível no teste. Não renomeie dados, drivers, projeto ou biblioteca.
6. Abra o domínio da segunda pasta. Confirme o novo caminho na barra de título.
7. Abra o Viewer e visite todas as telas; confira fundos, ícones e símbolos que usam imagens.
8. Se faltou imagem, volte à etapa em que inseriu essa figura, incorpore o recurso no arquivo correto e refaça o vínculo pelo Organizer. Salve e repita o teste.
9. Ao terminar, feche o Studio e restaure os nomes das pastas de imagens de origem. Não apague nenhuma pasta.
10. O melhor teste final é abrir a entrega em outro computador onde os caminhos dos autores nunca existiram. Esse teste também revela DLL/provider ausente, que é problema diferente de asset.
11. Considere o teste concluído quando todas as imagens aparecerem após reabrir sem as pastas-fonte.

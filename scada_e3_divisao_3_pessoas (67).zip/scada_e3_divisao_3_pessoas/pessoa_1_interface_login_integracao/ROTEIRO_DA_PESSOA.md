# Pessoa 1 — interface geral, navegação, login e integração

Sua função é montar a estrutura visual que recebe as telas dos colegas. Você também reúne as entregas no final. Não mexa no Driver1, na biblioteca ou nos históricos.

## Seus objetos — responsabilidade exclusiva

- TelaInicial, TelaMenu, TelaUsuarios.
- Viewer1 e Quadro1.
- Fundos/ícones usados por essas telas.
- Contas e permissões do domínio FINAL, depois da integração.

Não edite TelaOperacao/TelaCondicoes (pessoa 3), nem TelaEventos/TelaHistorico/TelaAlarmes (pessoa 2). Não crie páginas provisórias com esses cinco nomes: elas causariam conflitos na integração.

## Comece aqui

1. Cada pessoa abre uma cópia da mesma versão atual do projeto. Antes de copiar, Salvar Tudo e fechar o Studio.
2. Edite somente os objetos da sua função, na sua cópia local.
3. Mantenha os nomes indicados nas tabelas: os scripts dependem deles.
4. Nas etapas com imagens, siga primeiro os passos de Inserir Recurso e só depois vincule a figura. A importação está na própria etapa de uso.
5. Quando terminar, Salvar Tudo, fechar o Studio e enviar a pasta completa à pessoa 1 para juntar as partes.

O CLP permanece como está. D2/D3 são acionados pelas chaves físicas. Se faltar um objeto que outro colega está criando, continue a montagem e conecte essa referência depois do merge; não crie tags fictícias.

## C1. Editar propriedades

1. Selecione o objeto na árvore **Organizer**, à esquerda.
2. Confira o nome no título do painel **Propriedades**, abaixo do Organizer.
3. Se esse painel estiver escondido, use **Lista de Propriedades** na barra/menu Visualizar.
4. No campo **Procurar**, escreva o nome da propriedade, por exemplo Width.
5. Clique na célula da coluna **Valor**, na mesma linha.
6. Digite o valor e pressione Enter.
7. Confira se o valor permaneceu.
8. Limpe Procurar antes de procurar outra propriedade.

**Name** é o nome técnico do objeto. **Value**, em Texto/Display nativo, é o conteúdo mostrado. **Caption**, em CommandButton, é o texto do botão. Não são a mesma coisa.

## C2. Colar um código em um evento

1. Abra a tela com duplo clique no Organizer.
2. Selecione o botão na árvore, não apenas um texto desenhado por cima dele.
3. Clique na aba inferior **Scripts**.
4. Na lista superior esquerda, confirme o nome do botão.
5. Na lista superior direita, escolha **Click**.
6. Leia as ações que já existem. Se houver Pick de abrir tela ou Script, não acrescente outra abertura igual.
7. Se estiver vazio, clique em **Script**, na barra desse editor.
8. O Studio cria a linha Sub e a linha End Sub.
9. Abra o .txt indicado em scripts_para_colar, no Bloco de Notas.
10. Copie o conteúdo.
11. No E3, clique na linha vazia entre Sub e End Sub e cole.
12. Não cole uma segunda assinatura Sub/End Sub. Os arquivos normais do pacote já são corpos de evento.
13. Clique em **Compila o script selecionado**, ou pressione F7 com o editor focado.
14. Corrija qualquer erro antes de executar.
15. Clique em Salvar Tudo.

Se estiver substituindo um código antigo, substitua o corpo desse Script; não crie um segundo Script fazendo a mesma coisa.

## C3. Associar uma leitura pelo AppBrowser

1. Selecione o objeto que deve mostrar a informação.
2. Ache sua propriedade de destino, por exemplo Value.
3. Abra a edição de **Associações**, pelo indicador ao lado da propriedade ou pela janela de propriedades do objeto.
4. Escolha **Simples** para ler a informação.
5. Abra o **AppBrowser** no campo de origem.
6. Navegue até a tag e a propriedade exata: por exemplo Driver1 → Aux_D1 → Value.
7. Confirme a seleção e feche com OK.
8. Confira que a associação ficou em Value, e não em Name ou X.
9. Não escolha Bidirecional para os contatos de posição.

Os nomes dos comandos de inserção/diálogos podem variar na sua instalação. Use o nome do objeto e da propriedade para localizar o equivalente; não escolha um tipo diferente só porque está próximo no menu.

## P1.1 Preparar pastas e tamanhos

1. Na sua cópia, crie SCADA_UI/layout e SCADA_UI/icones junto ao .prj.
2. Copie assets/layout e assets/icones deste pacote para essas pastas.
3. Configure SOMENTE TelaInicial: Width=50800; Height=2540.
4. Configure SOMENTE TelaMenu: Width=6773,33; Height=26035.
5. Crie apenas TelaUsuarios, se ausente, no .prj existente, com 1664×984 pixels no assistente, ou Width=44026,67 e Height=26035 nas propriedades.
6. Não crie as telas dos colegas. O menu já pode apontar para seus nomes, mas os testes desses destinos ficarão pendentes.
7. Não altere o tamanho de TelaOperacao: é responsabilidade da pessoa 3.
8. Salve Tudo.


## P1.2 Importar o fundo e montar o cabeçalho

Faça a importação abaixo antes de preencher PictureFile.

1. No Organizer, expanda **Visualização → Recursos**.
2. Clique com o botão direito em Recursos e escolha **Inserir Recurso Em → o .prj que contém TelaInicial**.
3. No seletor do Windows, escolha **assets/layout/cabecalho_base.png** deste pacote, ou sua cópia em SCADA_UI/layout.
4. Confirme. O arquivo deve aparecer como item dentro de Recursos do E3.
5. Renomeie esse recurso para **P1_Cabecalho**. Se o editor ajustar o nome, use o item real nos passos seguintes.
6. Salve Tudo. A imagem agora está incorporada no .prj; o arquivo externo serviu apenas para importá-la.
7. Abra TelaInicial e selecione a própria tela no Organizer.
8. Configure **FillStyle=12 — Picture / bkPicture**.
9. Deixe a linha **PictureFile** visível no painel de propriedades.
10. Arraste **P1_Cabecalho de Recursos do E3** para a célula de valor de PictureFile. Não arraste o PNG do Explorer do Windows nem cole C:\Users nesse campo.
11. Configure **PicturePosition=2 — Stretch**.
12. Confira o título SCADA / SUBESTAÇÃO. Preserve a referência de recurso gerada pelo E3; não a substitua por um caminho externo.
13. Selecione os textos antigos Entrar/Sair, ajuste a cor para RGB 23,43,58 e reposicione dentro da faixa do cabeçalho.
14. Crie dois CommandButtons com as propriedades abaixo:

| Name | Caption | X | Y | Width | Height |
|---|---|---:|---:|---:|---:|
| btnLogin | Entrar | 43391,67 | 635 | 2645,83 | 1164,17 |
| btnLogout | Sair | 46566,67 | 635 | 2645,83 | 1164,17 |

15. Se os textos antigos duplicarem os Captions, deixe esses textos invisíveis ou como rótulos sem ação.
16. Os scripts de sessão entram em P1.8. Não dê login ao texto e ao botão simultaneamente.
17. Salve Tudo.


## P1.3 Importar o fundo do menu

1. No Organizer, abra **Visualização → Recursos**.
2. Clique com o botão direito em Recursos → **Inserir Recurso Em → o .prj que contém TelaMenu**.
3. Selecione **assets/layout/menu_fundo.png**, confirme e nomeie o recurso **P1_MenuFundo**.
4. Salve Tudo antes de aplicar a imagem.
5. Abra TelaMenu e selecione a própria tela.
6. Configure **FillStyle=12** e **PicturePosition=2**.
7. Arraste **P1_MenuFundo do Organizer** para a célula **PictureFile**. Não selecione o arquivo externo novamente.
8. Confira o menu escuro e Salve Tudo.
9. Em TelaUsuarios, use preenchimento sólido RGB 243,245,247 e texto RGB 23,43,58. Essa tela não precisa de imagem de fundo.
10. Use Segoe UI. Não altere as telas dos colegas.


## P1.4 Dividir o Quadro

O Quadro divide a janela. A estrutura final deve ser:

```text
Quadro1
  Cabecalho -> TelaInicial
  Corpo
    Menu -> TelaMenu
    Conteudo -> TelaOperacao inicialmente
```

1. No Organizer, expanda **Visualização → Viewer e Quadros**.
2. Abra Quadro1. Não crie outro.
3. Confira as divisões existentes antes de acrescentar novas. Reaproveite as equivalentes.
4. Se estiver inteiro, selecione a área principal e use **Dividir Horizontalmente** no editor/contexto do Quadro.
5. Selecione a região que vai ficar em cima.
6. Abra as propriedades dessa região.
7. Configure os campos da primeira tabela:

| Campo da região superior | Valor |
|---|---|
| Nome | Cabecalho |
| SplitDockPosition | dockTop |
| SplitValue | 96px |
| SplitResizable | False |
| SplitLink | TelaInicial?4?0 |

8. Para escolher a tela, prefira **Selecionar Tela ou Quadro**, escolha TelaInicial e selecione Zoom=Preencher, sem rolagem. O sufixo ?4?0 representa essas opções.
9. Selecione a região inferior. Nomeie **Corpo** e mantenha dockRemaining.
10. Com **somente Corpo selecionado**, use **Dividir Verticalmente**.
11. Selecione a região da esquerda e configure:

| Campo | Valor |
|---|---|
| Nome | Menu |
| SplitDockPosition | dockLeft |
| SplitValue | 256px |
| SplitResizable | False |
| SplitLink | TelaMenu?4?0 |

12. Selecione a região da direita e configure:

| Campo | Valor |
|---|---|
| Nome | Conteudo |
| SplitDockPosition | dockRemaining |
| SplitLink | TelaOperacao?4?0 |

13. Confira a estrutura contra o desenho acima.
14. Se o menu ocupar a faixa de cima, confira se dividiu Corpo, e não Cabecalho.
15. Escreva px no SplitValue. O número sem unidade pode ser interpretado como HIMETRIC.
16. Salve Tudo.


## P1.5 Configurar o Viewer

1. Selecione Viewer1 no Organizer.
2. Procure **InitialScreen** na lista de propriedades.
3. Escolha **Quadro1**.
4. Não use TelaInicial como InitialScreen: ela será somente o cabeçalho dentro do Quadro.
5. Não crie outro Viewer. Não transforme _top em uma tela nova.
6. Salve Tudo.


## P1.6 Fazer o menu

1. Abra TelaMenu.
2. Selecione CommandButton1 e confira suas ações de Click na aba Scripts.
3. Faça o mesmo nos outros dois. Não duplique navegação já existente.
4. Renomeie os três primeiros para btnSinotico, btnEventos e btnHistorico.
5. Crie mais três CommandButtons: btnAlarmes, btnCondicoes e btnUsuarios, se ainda não existirem.
6. Em todos, configure **X=317,50; Width=6138,33; Height=1587,50**.
7. Configure Caption e Y pela tabela:

| Name | Caption | Y | Arquivo do Click, em scripts_para_colar |
|---|---|---:|---|
| btnSinotico | Sinótico | 2434,17 | menu_sinotico.txt |
| btnEventos | Tabela de eventos | 4445 | menu_eventos.txt |
| btnHistorico | Histórico | 6455,83 | menu_historico.txt |
| btnAlarmes | Alarmes | 8466,67 | menu_alarmes.txt |
| btnCondicoes | Condições de operação | 10477,50 | menu_condicoes.txt |
| btnUsuarios | Usuários | 12488,33 | menu_usuarios.txt |

8. Use o procedimento procedimento C2 para colar cada arquivo no Click correspondente.
9. Se preferir um Pick de Abrir Tela já existente, ajuste seu destino, divisor Conteudo e zoom Preencher. Nesse caso, não acrescente também o Script de navegação.
10. O Script de Sinótico deve conter:

```vb
Application.GetFrame("Conteudo").OpenScreen "TelaOperacao?4?0", 0
```

11. Compile cada evento e Salve Tudo.

### Se quiser ícones nos botões, importe antes de inserir a Figura

1. Em Visualização → Recursos, use **Inserir Recurso Em** no .prj da TelaMenu.
2. Escolha o PNG em assets/icones, por exemplo eventos.png, e confirme.
3. Nomeie o recurso **P1_IconeEventos**. Faça o mesmo para cada ícone realmente usado; não é necessário importar todos.
4. Só então insira uma **Figura nativa** na tela.
5. Selecione a Figura e procure **Filename**.
6. Arraste o recurso do Organizer para Filename ou use o seletor de recursos do objeto. Não escolha de novo o PNG pelo Windows.
7. Posicione o ícone ao lado do botão sem cobrir sua área de clique. Teste o clique e Salve Tudo.
8. Se o objeto não aceitar recurso incorporado, deixe esse ícone opcional de fora ou use uma Figura nativa compatível.


## P1.7 Testar sem depender dos colegas

1. Compile os seis eventos do menu sem acionar os destinos ausentes.
2. Se Quadro1 aponta inicialmente para TelaOperacao já existente na base, abra o Viewer normalmente.
3. Confira encaixe de cabeçalho/menu/conteúdo.
4. Teste Sinótico, que ainda é a cópia antiga não editada por você, e Usuários, que é sua tela.
5. Se um destino de outra pessoa ainda não existe, teste esse destino depois do merge. Não crie uma tela com esse nome só para o teste passar.
6. Depois da integração, clique nos seis destinos e confira a permanência de menu/cabeçalho.
7. Sem dados reais, não avalie manobras. Seu teste é de interface e acesso.


## P1.8 Login e acesso

### 18.1 Botões do cabeçalho

1. Abra TelaInicial e selecione btnLogin.
2. Cole login.txt no Click, seguindo procedimento C2.
3. Em btnLogout, cole logout.txt.
4. Compile os dois.
5. Crie um Texto/Display chamado txtUsuario com o rótulo Usuário atual ao lado.
6. Associe Value à propriedade **User do Viewer**, escolhida pelo AppBrowser. Não use um Tag global para representar o usuário de cada Viewer.
7. Se a propriedade não aparecer, deixe o indicador pendente e mantenha o diálogo nativo. Não invente um caminho de servidor.

### 18.2 Contas e permissões

1. Abra **Arquivo → Usuários**, ou o comando de usuários disponível no domínio.
2. Se já houver administrador, use a conta autorizada do projeto para editar as contas.
3. Se não houver, siga o diálogo nativo para cadastrar o primeiro administrador. A edição pode depender disso.
4. Crie os grupos **OperadoresSCADA** e **AdministradoresSCADA**.
5. Crie uma conta administrativa e uma conta de operador para teste.
6. Escolha as senhas no diálogo do E3. Não as coloque nos scripts ou neste pacote.
7. Associe as contas aos grupos correspondentes.
8. Configure visitante/anônimo para consulta, sem escrita operacional.
9. Configure o operador para somente os três comandos previstos.
10. Aplique as restrições usando os recursos nativos de permissões de escrita e de operação dos objetos. Só esconder botão não protege a tag.
11. Abra TelaUsuarios e crie btnAdministrarUsuarios, Caption=Administrar usuários.
12. Cole administrar_usuarios.txt no Click e restrinja a administração ao administrador.
13. No Viewer, teste Entrar, cancelamento do diálogo, login válido e Sair.
14. Depois de Sair, confirme o estado anônimo e a restrição de operação.
15. Não teste as permissões acionando memórias da bancada nesta preparação.

### Ajuste específico para trabalho paralelo

Na sua cópia, use login.txt e logout.txt simples. A pessoa 2 prepara BD_SCADA/HistEventos; só após integração substitua os corpos pelos arquivos login_com_registro_demo.txt e logout_com_registro_demo.txt. Não some os códigos antigos aos novos.

As contas locais de teste pertencem ao seu .dom e NÃO serão mescladas automaticamente no domínio da pessoa 3. Depois da integração, configure manualmente usuários e permissões no .dom FINAL. Não envie senhas na entrega. A pessoa 3 deixa os comandos desabilitados; só habilite após contrato conferido na bancada e permissões nativas aplicadas.


## P1.9 Juntar as partes

1. Salve Tudo, feche o Studio e guarde sua pasta como ENTREGA_P1.
2. Receba as pastas completas das pessoas 2 e 3.
3. Siga 01_INTEGRACAO_FINAL.md para juntar os objetos no E3.
4. Configure os usuários no domínio final e use login/logout com registro depois que o banco funcionar.


## Testar as imagens depois de montar

1. Salve Tudo e feche o Viewer e o Studio.
2. Copie a aplicação entregue para uma segunda pasta com outro nome, por exemplo TESTE_PORTABILIDADE_SCADA.
3. Nessa cópia, mantenha .dom, todos os .prj, a .lib, DLLs e a pasta dados necessária.
4. Feche todas as instâncias antigas antes do teste, para evitar imagem carregada em cache.
5. Renomeie temporariamente APENAS a pasta externa de imagens usada como fonte no seu computador, por exemplo SCADA_UI para SCADA_UI_FONTE_TEMP. Se o arquivo original foi lido de assets do pacote, essa pasta de origem também precisa ficar indisponível no teste. Não renomeie dados, drivers, projeto ou biblioteca.
6. Abra o domínio da segunda pasta. Confirme o novo caminho na barra de título.
7. Abra o Viewer e visite todas as telas; confira fundos, ícones e símbolos que usam imagens.
8. Se faltou imagem, volte à etapa em que inseriu essa figura, incorpore o recurso no arquivo correto e refaça o vínculo pelo Organizer. Salve e repita o teste.
9. Ao terminar, feche o Studio e restaure os nomes das pastas de imagens de origem. Não apague nenhuma pasta.
10. O melhor teste final é abrir a entrega em outro computador onde os caminhos dos autores nunca existiram. Esse teste também revela DLL/provider ausente, que é problema diferente de asset.
11. Considere o teste concluído quando todas as imagens aparecerem após reabrir sem as pastas-fonte.

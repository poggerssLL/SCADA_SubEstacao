﻿# Merge das três partes — pessoa 1

Use este procedimento quando as três pessoas terminarem. Faça tudo em cópias, com Viewer e domínio parados.

## 1. Separar as pastas

1. Receba as pastas completas dos três projetos e guarde como ENTREGA_P1, ENTREGA_P2 e ENTREGA_P3.
2. Copie ENTREGA_P3 para uma nova pasta chamada FINAL_INTEGRADO.
3. Guarde outra cópia dessa pasta como backup antes de começar.
4. Preserve Driver1, DadosEquipamentos, TelaOperacao, TelaCondicoes e a biblioteca_subestacao.lib da pessoa 3.
5. Não copie o .prj da pessoa 1 ou 2 por cima do .prj da pessoa 3.

## 2. Separar os objetos da pessoa 1 em um módulo

Faça isso numa cópia de ENTREGA_P1 chamada TRANSFERENCIA_P1, sem mexer no projeto final ainda.

1. Abra o domínio da pasta TRANSFERENCIA_P1.
2. No Studio, selecione o modo **Explorer** para enxergar os arquivos e seus objetos.
3. Clique com o botão direito em Arquivos e use **Novo Arquivo de Aplicação (.PRJ)**.
4. Crie **UI_Navegacao.prj** nesse domínio temporário.
5. No Explorer, selecione a TelaInicial inteira, mantenha Ctrl pressionado e arraste para UI_Navegacao.prj. Isso copia a tela.
6. Repita para TelaMenu e TelaUsuarios.
7. Copie também Viewer1 e Quadro1 com seus filhos, usando Copiar/Colar quando habilitado no Explorer.
8. Se o editor não permitir copiar Viewer/Quadro, recrie esses dois objetos no módulo seguindo o roteiro da pessoa 1. Não leve o projeto inteiro para contornar isso.
9. Antes de configurar imagens das telas copiadas, no Explorer clique com o botão direito em **UI_Navegacao.prj → Inserir Recurso**. Escolha cabecalho_base.png, menu_fundo.png e os ícones realmente usados, nos assets da pessoa 1. Confirme e preserve os nomes P1_Cabecalho/P1_MenuFundo dos respectivos recursos.
10. Abra TelaInicial/TelaMenu no módulo, configure FillStyle=12 e PicturePosition=2 e arraste cada recurso do Organizer para PictureFile. Nas Figuras, arraste o recurso para Filename. Não selecione um caminho externo. Salve Tudo.
11. Não copie Driver1, outras telas ou a biblioteca.
12. No Explorer, clique no projeto ORIGINAL desse domínio temporário e use **Remover do Domínio**. Isso retira o arquivo da lista; não apague o arquivo do disco.
13. Se as cópias receberam números/sufixos, renomeie-as para TelaInicial, TelaMenu, TelaUsuarios, Viewer1 e Quadro1.
14. Confira Viewer1.InitialScreen=Quadro1, as regiões do Quadro e os seis destinos do menu. Corrija qualquer nome temporário em Scripts e SplitLink.
15. Salve Tudo e feche o Studio.

As telas dos colegas ainda não estarão nesse módulo. Elas entrarão pela base da pessoa 3 e pelo módulo seguinte.

## 3. Separar os objetos da pessoa 2 em um módulo

1. Faça uma cópia de ENTREGA_P2 chamada TRANSFERENCIA_P2 e abra seu domínio.
2. No Explorer, crie um novo arquivo **Dados_Registros.prj**.
3. Copie as três telas inteiras para esse arquivo, mantendo Ctrl ao arrastar:

| Tela |
|---|
| TelaEventos |
| TelaHistorico |
| TelaAlarmes |

4. Copie também estes objetos raiz, com seus filhos, usando as opções nativas do Explorer:

| Objeto |
|---|
| BD_SCADA |
| DadosEventos |
| HistEventos |
| HistContatos |
| ServidorAlarmes |
| ConfigAlarmes |

5. Se um tipo não puder ser copiado no seu editor, recrie esse objeto no módulo usando o roteiro da pessoa 2.
6. Se as telas usam imagens, clique com o botão direito em **Dados_Registros.prj → Inserir Recurso**, selecione os PNG/BMP usados e confirme. Só depois abra as Figuras nas telas copiadas e arraste os recursos do Organizer para Filename. Se forem apenas fundo sólido/E3Browser/E3Alarm, não há imagem a importar.
7. Não copie Driver1 nem Viewer1.
8. Remova apenas o projeto original da lista desse domínio temporário, por **Remover do Domínio**.
9. Restaure os nomes originais dos objetos copiados se o Studio acrescentou sufixos.
10. Confira BDServer/DBServer, consultas dos Browsers e fontes dos Históricos pelos campos reais de cada editor. Use BD_SCADA como banco dos Históricos.
11. Salve Tudo e feche o Studio.

## 4. Colocar os dois módulos no projeto final

1. Copie UI_Navegacao.prj e Dados_Registros.prj para a pasta FINAL_INTEGRADO.
2. Abra o domínio dessa pasta. Confira FINAL_INTEGRADO no caminho da barra de título.
3. Mantenha o domínio parado.
4. Antes de adicionar os módulos, retire no Studio as versões antigas dos objetos abaixo, **somente se a versão nova já estiver pronta no módulo correspondente**. O backup do passo 1 preserva os antigos.

| Versões antigas a substituir | Nova versão em |
|---|---|
| TelaInicial, TelaMenu, TelaUsuarios, Viewer1, Quadro1 | UI_Navegacao.prj |
| TelaEventos, TelaHistorico, TelaAlarmes | Dados_Registros.prj |
| BD_SCADA, DadosEventos, HistEventos, HistContatos | Dados_Registros.prj |
| ServidorAlarmes, ConfigAlarmes | Dados_Registros.prj |

5. Apague apenas esses objetos antigos na cópia final. Não apague o .prj que também contém aquisição e sinótico.
6. Preserve Driver1, DadosEquipamentos, TelaOperacao, TelaCondicoes e a biblioteca da pessoa 3.
7. Pelo Explorer, abra UI_Navegacao.prj e use **Adicionar ao Domínio**.
8. Repita com Dados_Registros.prj.
9. Não adicione os três projetos completos das entregas ao domínio final.
10. Confira que cada nome de objeto aparece uma única vez.
11. Registre as bibliotecas carregadas e Salve Tudo.

## 5. Ajustar os recursos e o banco no destino

1. Abra as telas no projeto final e confira os fundos/ícones.
2. Se uma imagem faltar, primeiro clique com o botão direito no módulo que contém a tela → **Inserir Recurso**, selecione o PNG/BMP e confirme. Depois selecione a tela/Figura e arraste esse novo item do Organizer para PictureFile/Filename. Salve Tudo.
3. Não volte a escolher C:\Users do autor como origem da imagem.
4. Em BD_SCADA, configure **dados\scada.mdb** para a pasta FINAL_INTEGRADO.
5. Se o campo exigir caminho absoluto, selecione a pasta dados desse computador final.
6. Teste a conexão.
7. Se já existe um banco final com dados, não sobrescreva pelo banco de teste da pessoa 2. Se não existe, use o banco recebido ou crie um novo e gere as estruturas pelos Históricos/ServidorAlarmes.
8. Não reinicialize tabelas com registros a preservar.
9. Em HistContatos, confira as fontes dos 13 contatos e suas qualidades, agora com Aux_S/Aux_D disponíveis.
10. Confira que só há um Driver1 e que a receita continua com 19 tags de comunicação.

## 6. Conectar login, consulta e permissões

1. Na TelaInicial, substitua o corpo do Click de btnLogin por login_com_registro_demo.txt.
2. Substitua o corpo do Click de btnLogout por logout_com_registro_demo.txt.
3. Não mantenha os scripts simples além desses novos: eles já incluem a ação de sessão.
4. Na TelaCondicoes, habilite btnRegistrarConsulta depois de confirmar que BD_SCADA e HistEventos funcionam.
5. Configure usuários/grupos e permissões no .dom final. As contas dos outros .dom não são mescladas automaticamente.
6. Compile os eventos alterados e Salve Tudo.
7. Mantenha Ligar, Desligar e Falha B1 desabilitados até conferir o contrato das memórias na bancada.

## 7. Abrir e testar o conjunto

1. Abra Viewer1 por Quadro1.
2. Clique nos seis destinos e veja se cabeçalho/menu permanecem.
3. Teste Entrar, cancelar o diálogo e Sair.
4. Faça uma anotação em TelaEventos, atualize e confira se permanece após reabrir o Viewer.
5. Abra o histórico e confira a consulta e as colunas de qualidade.
6. Abra TelaCondicoes. Sem contatos válidos, o resultado deve ser inconclusivo, não conforme.
7. Faça o teste de portabilidade das imagens descrito em 02_IMPORTAR_ASSETS_SEM_CAMINHO.md: reabrir sem as pastas-fonte de imagens disponíveis.
8. Salve Tudo, feche e leve a pasta FINAL_INTEGRADO completa para a bancada.

A cópia de telas por Ctrl+arrastar é documentada pela Elipse. Para os demais objetos, use as opções que o Explorer da instalação oferecer; se não houver cópia, recrie apenas o objeto correspondente pelo guia. [Referência de cópia de telas](https://kb.elipse.com.br/kb28109-copiando-uma-tela-de-um-projeto-para-outro/), [Explorer e arquivos do domínio](https://docs.elipse.com.br/documents/pt-br/e3/v6.7.236/manual/e3/manual_studio_organizer.html).

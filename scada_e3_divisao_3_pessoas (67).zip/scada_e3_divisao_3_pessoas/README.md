# Distribuição dos três roteiros

1. Todos leem [00_COMECEM_AQUI.md](00_COMECEM_AQUI.md), combinam a BASE_COMUM e assumem uma função.
2. Cada pessoa segue somente seu guia, que já contém os procedimentos de edição, os seus passos e a importação de assets como Recursos:

| Pessoa | Guia |
|---|---|
| 1 — interface, login e integração | [Roteiro da pessoa 1](pessoa_1_interface_login_integracao/ROTEIRO_DA_PESSOA.md) |
| 2 — eventos, histórico e alarmes | [Roteiro da pessoa 2](pessoa_2_eventos_historico_alarmes/ROTEIRO_DA_PESSOA.md) |
| 3 — contatos, biblioteca, sinótico e condições | [Roteiro da pessoa 3](pessoa_3_sinotico_contatos_condicoes/ROTEIRO_DA_PESSOA.md) |

3. No fim, sigam [01_INTEGRACAO_FINAL.md](01_INTEGRACAO_FINAL.md), com cópia de objetos/módulos, resolução de nomes, domínio final e conferência conjunta.
4. A importação de cada imagem aparece diretamente na etapa que vai usá-la, antes de configurar PictureFile/Filename. [02_IMPORTAR_ASSETS_SEM_CAMINHO.md](02_IMPORTAR_ASSETS_SEM_CAMINHO.md) fica como referência opcional. No fim dos guias há apenas o teste de portabilidade.
5. Cada pasta individual contém seu roteiro, scripts, assets e os procedimentos de merge/importação. Distribua o pacote individual para a pessoa correspondente. Não há formulário ou relatório para preencher.

São instruções e materiais de montagem, não três .prj/.lib nativos gerados. Cada pessoa começa com uma cópia da mesma base ATUAL escolhida pelo grupo. O trabalho no Studio e o merge precisam ser executados e conferidos conforme os guias; não foram realizados nesta divisão documental.

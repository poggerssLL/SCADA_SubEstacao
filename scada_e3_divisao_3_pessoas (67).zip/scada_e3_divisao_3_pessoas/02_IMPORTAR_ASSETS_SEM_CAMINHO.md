# Importar imagens como Recursos — sem depender de C:\Users de cada pessoa

Neste trabalho, imagens usadas nas telas devem ser incorporadas no .prj ou .lib responsável, e os objetos devem referenciar esses Recursos. Copiar um PNG para a pasta do projeto e continuar selecionando seu caminho externo não resolve essa dependência.

## 1. Onde cada pessoa incorpora os seus recursos

| Pessoa | Onde guardar | Convenção de nome |
|---|---|---|
| 1 | Projeto que contém TelaInicial/TelaMenu/TelaUsuarios; no módulo exportado, UI_Navegacao.prj | P1_Cabecalho, P1_MenuFundo, P1_IconeLogin etc. |
| 2 | Projeto das telas de registros; no módulo exportado, Dados_Registros.prj | P2_IconeEventos, P2_IconeHistorico, P2_IconeAlarmes |
| 3 | Projeto do sinótico para imagens de tela; biblioteca_subestacao.lib para imagens internas de suas classes | P3_... |

O desenho vetorial nativo de TelaOperacao já existe e não precisa virar PNG. Só incorpore imagens realmente usadas. Não acrescente sinotico_base como outro desenho por baixo.

## 2. Inserir um PNG/BMP no arquivo certo

1. Abra sua cópia do domínio no Studio.
2. No Organizer, expanda **Visualização → Recursos**.
3. Clique com o botão direito em **Recursos**.
4. Escolha **Inserir Recurso Em** e selecione o .prj ou .lib de sua responsabilidade.
5. Alternativa: no modo Explorer, clique com o botão direito diretamente nesse arquivo e escolha **Inserir Recurso**.
6. No seletor de arquivos do Windows, escolha o PNG/BMP de origem fornecido em assets.
7. Confirme a inserção.
8. Confira o novo item em Recursos. O seletor usou um caminho para ler a imagem; agora o conteúdo precisa estar no projeto/biblioteca.
9. Renomeie o recurso para o nome combinado, usando a propriedade/comando de renomear do editor.
10. Se o editor não permitir esse nome/formato, use uma variação válida. Nos vínculos seguintes, selecione esse mesmo item pelo Organizer.
11. Confira no Explorer em qual .prj/.lib o recurso foi inserido. O nome do arquivo de destino importa quando vocês levarem o módulo ao domínio final.
12. Salve Tudo.

## 3. Vincular o fundo da TelaInicial ao recurso

Exemplo da pessoa 1:

1. Insira assets/layout/cabecalho_base.png como Recurso e nomeie **P1_Cabecalho**.
2. Abra TelaInicial e selecione a própria tela no Organizer.
3. Na Lista de Propriedades, configure **FillStyle=12 — Picture / bkPicture**.
4. Localize **PictureFile** e deixe essa linha visível.
5. No Organizer, arraste o item **P1_Cabecalho**, de Recursos, diretamente para a célula de valor de PictureFile.
6. Não arraste o arquivo do Explorer do Windows para esse campo: queremos o Recurso do E3.
7. Configure **PicturePosition=2 — Stretch**.
8. Confira que o fundo apareceu e que PictureFile recebeu a referência gerada pelo E3 para o recurso.
9. Não substitua essa referência por C:\Users\...\cabecalho_base.png.
10. Não invente manualmente um prefixo de recurso. Use arrastar/selecionar o item do E3 e preserve o formato que o editor gerar.
11. Salve Tudo.

Repita para TelaMenu usando assets/layout/menu_fundo.png → **P1_MenuFundo** → PictureFile de TelaMenu. Cada recurso é importado uma vez por arquivo, mesmo que usado em mais de um objeto.

## 4. Vincular ícones e outras figuras

1. Insira o PNG/BMP como Recurso no arquivo que será entregue com a tela/classe.
2. Selecione a Figura/objeto que o usa.
3. Localize sua propriedade de arquivo/imagem. Para Figura nativa, procure **Filename**; Tela usa **PictureFile**. Outros tipos de objeto podem expor outra propriedade.
4. Se o editor aceitar, arraste o recurso do Organizer para essa propriedade; caso haja seletor de recursos, escolha o recurso incorporado por ele.
5. Não escolha novamente o arquivo externo pelo seletor do Windows.
6. Se o tipo de objeto só aceitar arquivo externo e não recurso, prefira a Figura nativa que aceite o recurso ou deixe o ícone opcional de fora. Não declare esse caso portátil sem testar.
7. Confira o ícone e o clique do botão; uma figura por cima do botão pode interceptar o mouse.
8. Salve Tudo.

## 5. Quando copiar telas para outro .prj durante o merge

1. Copiar uma tela não prova que todos os recursos de origem foram incorporados ao destino.
2. No .prj/.lib de destino, confira os Recursos usados pela tela.
3. Se faltarem, use Inserir Recurso nesse arquivo de destino, lendo a imagem dos assets da entrega.
4. Use nomes com o prefixo P1/P2/P3 para reduzir colisões.
5. Abra as telas/objetos no DESTINO e refaça os vínculos PictureFile/Filename selecionando os Recursos que existem no destino.
6. Confira também referências internas da biblioteca se ela usa imagens.
7. Salve, feche e reabra o domínio final.
8. Não deixe o módulo final dependendo de um recurso que existe apenas no .prj doador, que será removido do domínio.
9. Se o recurso tiver o mesmo nome de outro, confira conteúdo/arquivo de origem. Não aceite silenciosamente uma imagem diferente por ter nome igual.

## 6. Teste obrigatório de portabilidade, sem apagar nada

1. Salve Tudo e feche o Viewer e o Studio.
2. Copie a aplicação entregue para uma segunda pasta com outro nome, por exemplo TESTE_PORTABILIDADE_SCADA.
3. Nessa cópia, mantenha .dom, todos os .prj, a .lib, DLLs e a pasta dados necessária.
4. Feche todas as instâncias antigas antes do teste, para evitar imagem carregada em cache.
5. Renomeie temporariamente APENAS a pasta externa de imagens usada como fonte no seu computador, por exemplo SCADA_UI para SCADA_UI_FONTE_TEMP. Se o arquivo original foi lido de assets do pacote, essa pasta de origem também precisa ficar indisponível no teste. Não renomeie dados, drivers, projeto ou biblioteca.
6. Abra o domínio da segunda pasta. Confirme o novo caminho na barra de título.
7. Abra o Viewer e visite todas as telas; confira fundos, ícones e símbolos que usam imagens.
8. Se faltou imagem, volte à etapa em que inseriu essa figura, incorpore o recurso no arquivo correto e refaça o vínculo pelo Organizer. Salve e repita o teste.
9. Ao terminar, feche o Studio e restaure os nomes das pastas de imagens de origem. Não apague nenhuma pasta.
10. O melhor teste final é abrir a entrega em outro computador onde os caminhos dos autores nunca existiram. Esse teste também revela DLL/provider ausente, que é problema diferente de asset.
11. Considere o teste concluído quando todas as imagens aparecerem após reabrir sem as pastas-fonte.

## 7. O que continua sendo arquivo externo

- .dom contém domínio e segurança e deve acompanhar a entrega.
- Todos os .prj e .lib usados devem acompanhar a entrega; recurso dentro de um módulo não acompanha outro módulo por mágica.
- A DLL do driver não deve ser importada como Recurso de imagem. Preserve a configuração/instalação e confira no computador final.
- O .mdb e demais arquivos de banco não viram Recursos. Configure BD_SCADA para dados\scada.mdb na pasta final e teste a conexão nesse computador. Não mantenha C:\Users do autor.
- Se o editor do banco exigir caminho absoluto, a pessoa 1/2 configura esse caminho uma vez no computador FINAL. Isso é uma dependência externa documentada, diferente das imagens incorporadas.

## Fontes oficiais

[Inserir imagens como Recursos](https://kb.elipse.com.br/kb36960-banco-de-imagens-para-telas-do-e3/), [arrastar Recurso para PictureFile](https://docs.elipse.com.br/documents/pt-br/e3/latest/tutorial/dev/tutorial_objeto_tela_exercicio_telainicial.html), [tipos de Recurso e limite para drivers](https://kb.elipse.com.br/kb36127-inserindo-recursos-no-elipse-e3/).
